#!/usr/bin/env bash
# 下载 arm64 的 tun2socks 二进制到 app/src/main/assets/tun2socks
# 需要联网，在电脑上执行（Linux / macOS / WSL）
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HERE/app/src/main/assets/tun2socks"
mkdir -p "$HERE/app/src/main/assets"

# xjasonlyu/tun2socks 的 Android 构建
URLS=(
  "https://github.com/xjasonlyu/tun2socks/releases/latest/download/tun2socks-android-arm64"
  "https://github.com/xjasonlyu/tun2socks/releases/latest/download/tun2socks-android-arm64-v8a"
)

for u in "${URLS[@]}"; do
  echo "==> try $u"
  if curl -fL --retry 3 -o "$DEST" "$u"; then
    chmod +x "$DEST"
    echo "OK -> $DEST ($(stat -c%s "$DEST" 2>/dev/null || stat -f%z "$DEST") bytes)"
    exit 0
  fi
done

echo "自动下载失败。手动做法："
echo "  1) 打开 https://github.com/xjasonlyu/tun2socks/releases"
echo "  2) 下载文件名含 android-arm64 的那个"
echo "  3) 改名为 tun2socks 放进 app/src/main/assets/"
exit 1
