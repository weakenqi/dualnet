# 双链路加速 DualNetAccel

WiFi 实测速率掉到阈值以下时，自动把流量按比例补进来；WiFi 恢复后自动退回。
免 root，走 Android 官方 `Network.bindSocket()`，不是关 WiFi 那种切换。

---

## 它到底怎么工作

```
   App 的流量
       │
       ▼
 ┌──────────────┐
 │  VpnService  │  建立 tun，接管全网流量
 └──────┬───────┘
        │ 原始 IP 包
        ▼
 ┌──────────────┐
 │  tun2socks   │  把 IP 包还原成 TCP 连接，转给本地 SOCKS5
 └──────┬───────┘
        │ 127.0.0.1:10800
        ▼
 ┌──────────────┐
 │ Socks5Server │  每条 CONNECT 调 registry.pick() 选链路
 └──────┬───────┘
        │ network.bindSocket(sock)
   ┌────┴────┐
   ▼         ▼
 wlan0    rmnet_data0
 (WiFi)    (流量)
```

三个文件对应三件事：

| 文件 | 职责 |
|---|---|
| `NetworkRegistry.kt` | 同时持有 WiFi 和蜂窝两个 `Network`，按权重给连接分配出口 |
| `SpeedProbe.kt` | 每 10 秒从 WiFi 链路实测一次下行速率，换算成 WiFi 权重 |
| `Socks5Server.kt` | 对每条连接 `bindSocket` 到选定链路，双向搬运数据 |

### 阈值规则

设下限 `low`、上限 `good`（单位 Mbps）：

| WiFi 实测 | WiFi 权重 | 行为 |
|---|---|---|
| 完全测不通（带宽 0） | 0% | 全部走流量。分过去只会超时，没意义 |
| `<= low`（还能通，就是慢） | `minWifiWeight`（默认 15%） | **保底并存**：大部分走流量，仍留一小部分走 WiFi |
| `low` ~ `good` 之间 | 15% → 100% 线性上升 | **真正的按比例辅助**：例如 `low=2 good=15`、实测 8Mbps → 权重 57% |
| `>= good` | 100% | 全部走 WiFi，不花流量 |

`minWifiWeight` 是保底权重，目的是让两条链路**任何时候都在同时承载**，
而不是在 WiFi 变差时退化成"只用流量"。想允许完全退让就设 0。

注意：WiFi 从头到尾**不会被断开**，`DualVpnService` 不调用任何 WiFi 开关。
变的只是"每条新连接从哪条链路出去"。

### 为什么这样能"叠加"

视频、网页、下载本身就是几十条独立的 TCP 连接。加权轮询把它们铺到两条链路上，
总吞吐接近两条之和。

**单条 TCP 连接不会被拆开**——内核按五元组哈希，物理上拆不开。
所以"开一路直播、单线程下载一个文件"不会跑出两倍速度，这是协议决定的，任何软件都做不到，
除非服务器也支持 MPTCP。

---

## 编译

```bash
# 1. 先拿 tun2socks 二进制（需要联网）
./fetch-tun2socks.sh

# 2. 用 Android Studio 打开本目录，或命令行
./gradlew assembleDebug

# 产物
app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

需要 Android SDK 34 + JDK 17。只打包了 `arm64-v8a`，麒麟 980 就是 arm64。

---

## 使用

1. 打开 App，填阈值下限 / 上限（默认 2 / 15 Mbps）
2. 点「开始」，系统弹出 VPN 授权，同意
3. WiFi 和移动数据**都要开着**
4. 通知栏常驻一条「双链路加速运行中」

界面每秒刷新一次「WiFi 实测」和「WiFi 权重」，能直接看到当前有没有在吃流量。

---

## 你要知道的限制

1. **华为的后台管控**：`设置 → 应用 → 应用启动管理 → 双链路加速 → 手动管理`，
   三个开关全开，否则服务会被杀。
2. **VPN 冲突**：同一时间只能有一个 VPN。装了加速器、公司 VPN、代理工具的话先关掉。
3. **蜂窝计费**：阈值调太低（比如 `good=50`）会常态吃流量。建议 `low=2`、`good=10~15`。
4. **探测目标**：默认 `https://speed.cloudflare.com/__down?bytes=3000000`。
   国内访问不稳的话改成你自己能稳定打开的地址，在 `SpeedProbe.DEFAULT_PROBE_URL`。
5. **UDP / QUIC**：tun2socks 默认转发 UDP，但部分 App 的 QUIC 会失败后回落 TCP，属正常。
6. **只在 WiFi 已连接时生效**：WiFi 完全断开时这就是个普通 VPN，所有流量走蜂窝。

---

## 调整方向

- 想让流量介入更积极：`low` 调高（比如 5），`good` 调高（比如 30）
- 想强制两条永远并存、绝不退化成纯流量：`minWifiWeight` 设 20~30
- 想允许 WiFi 差时完全交给流量：`minWifiWeight = 0`
- 想更省流量：`low` 保持 2，`good` 保持 15 以上
- 想纯 WiFi 优先、只在彻底不可用时才切：`low=0.5`、`good=1`
- 测速太频繁费流量：`WeightController.probeIntervalSec` 调到 30，`probeBudgetMs` 调到 2000
