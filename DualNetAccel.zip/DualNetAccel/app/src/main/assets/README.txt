把 tun2socks 的 android-arm64 二进制放在这个目录，文件名必须是：tun2socks

获取方式（在电脑上执行工程根目录的脚本）：
    ./fetch-tun2socks.sh

或手动：
    1) https://github.com/xjasonlyu/tun2socks/releases
    2) 下载文件名含 android-arm64 的那个
    3) 重命名为 tun2socks 放到这里

没有这个文件时 App 会提示“assets/tun2socks 不存在”，无法启动。
