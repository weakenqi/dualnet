package com.lcs.dualnet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.File
import java.io.FileOutputStream

class DualVpnService : VpnService() {

    companion object {
        private const val TAG = "DualVpn"
        private const val CH_ID = "dualnet"
        private const val NOTI_ID = 1001
        const val SOCKS_PORT = 10800

        const val ACTION_START = "com.lcs.dualnet.START"
        const val ACTION_STOP = "com.lcs.dualnet.STOP"
        const val EXTRA_LOW_KBPS = "low_kbps"
        const val EXTRA_GOOD_KBPS = "good_kbps"

        @Volatile var isRunning = false; private set
    }

    private var tun: ParcelFileDescriptor? = null
    private var tun2socks: Process? = null
    private var registry: NetworkRegistry? = null
    private var socks: Socks5Server? = null
    private var weight: WeightController? = null
    private var lowKbps: Long = 2_000
    private var goodKbps: Long = 15_000

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopAll(); return START_NOT_STICKY }
            else -> {
                lowKbps = intent?.getLongExtra(EXTRA_LOW_KBPS, 2000) ?: 2000
                goodKbps = intent?.getLongExtra(EXTRA_GOOD_KBPS, 15000) ?: 15000
                startAll()
            }
        }
        return START_STICKY
    }

    private fun startAll() {
        if (isRunning) return
        goForeground()
        runCatching { startTun() }
            .onFailure {
                Log.e(TAG, "start failed", it)
                stopAll()
            }
    }

    private fun startTun() {
        // 1. 抓两个 Network
        val reg = NetworkRegistry(this).also { registry = it }
        reg.start()

        // 2. 本地 SOCKS5（每条连接按权重绑定 WiFi / 蜂窝）
        val s = Socks5Server(reg, protect = { sock -> protect(sock) }, port = SOCKS_PORT)
        s.start()
        socks = s

        // 3. 周期测速 -> 调整权重
        val w = WeightController(reg).apply {
            this.lowKbps = this@DualVpnService.lowKbps
            this.goodKbps = this@DualVpnService.goodKbps
        }
        w.start()
        weight = w

        // 4. 建 tun
        val builder = Builder()
            .setSession("DualNetAccel")
            .setMtu(1500)
            .addAddress("10.66.0.1", 32)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .addDnsServer("223.5.5.5")
            .addDnsServer("119.29.29.29")

        // 把自己排除掉，避免环路
        runCatching { builder.addDisallowedApplication(packageName) }

        val pfd = builder.establish() ?: throw IllegalStateException("establish() returned null")
        tun = pfd

        // 5. 拉起 tun2socks，把 tun fd 交给它
        startTun2Socks(pfd)

        isRunning = true
        Log.i(TAG, "running, low=${lowKbps}kbps good=${goodKbps}kbps")
    }

    private fun startTun2Socks(pfd: ParcelFileDescriptor) {
        val bin = File(filesDir, "tun2socks")
        if (!bin.exists()) extractBinary(bin)
        if (!bin.canExecute()) bin.setExecutable(true, false)

        val fd = pfd.detachFd()
        val cmd = listOf(
            bin.absolutePath,
            "-device", "fd://$fd",
            "-proxy", "socks5://127.0.0.1:$SOCKS_PORT",
            "-loglevel", "warn",
            "-tcp-sndbuf", "1048576",
            "-tcp-rcvbuf", "1048576",
        )
        Log.i(TAG, "exec: ${cmd.joinToString(" ")}")
        tun2socks = ProcessBuilder(cmd)
            .redirectErrorStream(true)
            .start()
            .also { p ->
                Thread {
                    runCatching {
                        p.inputStream.bufferedReader().forEachLine { line ->
                            Log.i("tun2socks", line)
                        }
                    }
                }.apply { isDaemon = true }.start()
            }
    }

    private fun extractBinary(dst: File) {
        assets.open("tun2socks").use { ins ->
            FileOutputStream(dst).use { outs -> ins.copyTo(outs) }
        }
        dst.setExecutable(true, false)
    }

    private fun stopAll() {
        isRunning = false
        runCatching { tun2socks?.destroy() }
        tun2socks = null
        runCatching { socks?.stop() }
        socks = null
        runCatching { weight?.stop() }
        weight = null
        runCatching { registry?.stop() }
        registry = null
        runCatching { tun?.close() }
        tun = null
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        stopSelf()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopAll()
        super.onRevoke()
    }

    // ---------- 前台通知 ----------

    private fun goForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CH_ID, "双链路加速", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = Notification.Builder(this, CH_ID)
            .setContentTitle("双链路加速运行中")
            .setContentText("WiFi 低于 ${lowKbps / 1000}Mbps 时自动用流量补足")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(NOTI_ID, n)
    }
}
