package com.lcs.dualnet

import android.util.Log
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * 本地 SOCKS5 服务。tun2socks 把 App 的流量送进来，
 * 这里对每条 CONNECT 调用 registry.pick() 选链路，
 * 再用 Network.bindSocket() 把上游 socket 钉死在 WiFi 或蜂窝上。
 *
 * 一条连接 = 一条 TCP 流，永远不会被拆开；但视频、网页、下载本身就是几十条连接，
 * 加权轮询会把它们铺到两条链路上，所以总带宽是两条之和。
 */
class Socks5Server(
    private val registry: NetworkRegistry,
    private val protect: (Socket) -> Boolean,
    private val port: Int = 10800,
) {
    companion object {
        private const val TAG = "Socks5"
        private const val CONNECT_TIMEOUT_MS = 10_000
    }

    private var serverSocket: ServerSocket? = null
    private var acceptThread: Thread? = null
    private val pool: ExecutorService = Executors.newCachedThreadPool { r ->
        Thread(r, "socks-conn").apply { isDaemon = true }
    }

    @Volatile private var running = false

    fun start() {
        if (running) return
        serverSocket = ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port))
        }
        running = true
        acceptThread = thread(name = "socks-accept", isDaemon = true) {
            while (running) {
                try {
                    val client = serverSocket!!.accept()
                    pool.execute { handleClient(client) }
                } catch (e: Exception) {
                    if (running) Log.w(TAG, "accept: ${e.message}")
                }
            }
        }
        Log.i(TAG, "listening on 127.0.0.1:$port")
    }

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        pool.shutdownNow()
    }

    private fun handleClient(client: Socket) {
        var remote: Socket? = null
        try {
            client.tcpNoDelay = true
            val ins = client.getInputStream()
            val outs = client.getOutputStream()

            // ---- 握手：VER NMETHODS METHODS ----
            if (ins.read() != 0x05) return
            val nMethods = ins.read()
            if (nMethods <= 0) return
            ins.readExact(nMethods)
            outs.write(byteArrayOf(0x05, 0x00))   // 无需认证
            outs.flush()

            // ---- 请求：VER CMD RSV ATYP DST.ADDR DST.PORT ----
            if (ins.read() != 0x05) return
            val cmd = ins.read()
            ins.read()  // RSV
            val atyp = ins.read()
            val host: String = when (atyp) {
                0x01 -> {   // IPv4
                    val b = ins.readExact(4)
                    InetAddress.getByAddress(b).hostAddress ?: return
                }
                0x03 -> {   // 域名
                    val len = ins.read()
                    if (len <= 0) return
                    String(ins.readExact(len), Charsets.UTF_8)
                }
                0x04 -> {   // IPv6
                    val b = ins.readExact(16)
                    InetAddress.getByAddress(b).hostAddress ?: return
                }
                else -> return
            }
            val pHi = ins.read(); val pLo = ins.read()
            if (pHi < 0 || pLo < 0) return
            val dstPort = (pHi shl 8) or pLo

            if (cmd != 0x01) {   // 只支持 CONNECT
                outs.write(byteArrayOf(0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
                outs.flush()
                return
            }

            // ---- 选链路 ----
            val network = registry.pick()
            val sock = Socket()
            // protect 防止上游 socket 被自己的 tun 再次捕获，形成环路
            protect(sock)
            if (network != null) {
                runCatching { network.bindSocket(sock) }
                    .onFailure { Log.w(TAG, "bindSocket failed: ${it.message}") }
            }
            remote = sock
            sock.tcpNoDelay = true
            sock.connect(InetSocketAddress(host, dstPort), CONNECT_TIMEOUT_MS)

            // 成功应答
            outs.write(byteArrayOf(0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
            outs.flush()

            // ---- 双向搬运 ----
            val up = pump(ins, sock.getOutputStream())
            val down = pump(sock.getInputStream(), outs)
            up.join()
            down.join()
        } catch (e: Exception) {
            Log.d(TAG, "client done: ${e.message}")
        } finally {
            runCatching { remote?.close() }
            runCatching { client.close() }
        }
    }

    private fun pump(from: InputStream, to: OutputStream): Thread = thread(isDaemon = true) {
        val buf = ByteArray(32 * 1024)
        try {
            while (true) {
                val n = from.read(buf)
                if (n <= 0) break
                to.write(buf, 0, n)
                to.flush()
            }
        } catch (_: Exception) {
        } finally {
            runCatching { to.close() }
            runCatching { from.close() }
        }
    }
}

/** Android minSdk 26 上没有 InputStream.readNBytes，自己实现 */
private fun InputStream.readExact(n: Int): ByteArray {
    val buf = ByteArray(n)
    var off = 0
    while (off < n) {
        val r = read(buf, off, n - off)
        if (r < 0) throw EOFException("unexpected end of stream")
        off += r
    }
    return buf
}
