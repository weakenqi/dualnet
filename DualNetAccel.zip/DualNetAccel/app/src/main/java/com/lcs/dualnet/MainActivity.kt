package com.lcs.dualnet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** service 把实时数据写在这里，Activity 只读 */
object Stats {
    @Volatile var wifiKbps: Long = -1
    @Volatile var weight: Int = 100
    @Volatile var running: Boolean = false
}

class MainActivity : Activity() {

    private val REQ_VPN = 100

    private lateinit var etLow: EditText
    private lateinit var etGood: EditText
    private lateinit var tvStatus: TextView
    private lateinit var btnToggle: Button

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        handler.post(ticker)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun buildUi(): ScrollView {
        val pad = (18 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "双链路加速"
            textSize = 22f
            setTextColor(Color.parseColor("#111111"))
            gravity = Gravity.START
        })

        root.addView(TextView(this).apply {
            text = "WiFi 实测低于「阈值下限」时全部走流量；" +
                   "介于下限和上限之间时按比例两条一起扛；" +
                   "高于上限时全部走 WiFi。单位 Mbps。"
            textSize = 13f
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, pad / 2, 0, pad)
        })

        etLow = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "阈值下限，默认 2"
            setText("2")
        }
        etGood = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "阈值上限，默认 15"
            setText("15")
        }
        root.addView(etLow)
        root.addView(etGood)

        btnToggle = Button(this).apply {
            text = "开始"
            setOnClickListener { onToggle() }
        }
        root.addView(btnToggle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = pad })

        tvStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#222222"))
            setPadding(0, pad, 0, 0)
        }
        root.addView(tvStatus)

        return ScrollView(this).apply { addView(root) }
    }

    private fun onToggle() {
        if (Stats.running) {
            startService(Intent(this, DualVpnService::class.java)
                .setAction(DualVpnService.ACTION_STOP))
            return
        }
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, REQ_VPN)
        } else {
            startVpn()
        }
    }

    @Deprecated("兼容旧 API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) startVpn()
            else Toast.makeText(this, "没有授予 VPN 权限", Toast.LENGTH_SHORT).show()
        }
    }

    private fun hasBinary(): Boolean = runCatching {
        assets.open("tun2socks").use { true }
    }.getOrDefault(false)

    private fun startVpn() {
        if (!hasBinary()) {
            Toast.makeText(
                this,
                "assets/tun2socks 不存在：先在电脑上跑 fetch-tun2socks.sh 再重新打包",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val low = ((etLow.text.toString().toDoubleOrNull() ?: 2.0) * 1000).toLong()
        val good = ((etGood.text.toString().toDoubleOrNull() ?: 15.0) * 1000).toLong()
        startService(Intent(this, DualVpnService::class.java)
            .setAction(DualVpnService.ACTION_START)
            .putExtra(DualVpnService.EXTRA_LOW_KBPS, low)
            .putExtra(DualVpnService.EXTRA_GOOD_KBPS, good))
    }

    private fun refresh() {
        Stats.running = DualVpnService.isRunning
        btnToggle.text = if (Stats.running) "停止" else "开始"
        tvStatus.text = buildString {
            appendLine("状态：${if (Stats.running) "运行中" else "未运行"}")
            appendLine("WiFi 实测：${fmt(Stats.wifiKbps)}")
            appendLine("WiFi 权重：${Stats.weight}%（其余走流量）")
            if (!Stats.running) {
                appendLine()
                appendLine("提示：WiFi 和流量必须同时开启；")
                appendLine("流量卡需要有数据业务，否则无法作为补充链路。")
            }
        }
    }

    private fun fmt(kbps: Long): String = when {
        kbps < 0 -> "测不通"
        kbps < 1000 -> "$kbps Kbps"
        else -> "%.1f Mbps".format(kbps / 1000.0)
    }
}
