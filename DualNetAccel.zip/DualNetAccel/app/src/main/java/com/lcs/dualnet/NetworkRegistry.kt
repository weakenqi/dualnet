package com.lcs.dualnet

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import java.util.concurrent.atomic.AtomicInteger

/**
 * 同时持有 WiFi 和蜂窝两个 Network 对象。
 *
 * 关键：requestNetwork() 不会改变系统默认网络，只是拿到一个可用的 Network 句柄。
 * 之后对任意 Socket 调 network.bindSocket(sock) 就能让这条连接从指定链路出去，
 * 这是 Google 公开 API，不需要 root。
 */
class NetworkRegistry(context: Context) {

    companion object { private const val TAG = "NetRegistry" }

    private val cm = context.getSystemService(ConnectivityManager::class.java)

    @Volatile var wifi: Network? = null; private set
    @Volatile var cellular: Network? = null; private set

    /** WiFi 权重 0..100。100=全走 WiFi，0=全走蜂窝，50=各一半。由测速模块动态调整。 */
    @Volatile var wifiWeight: Int = 100

    /** 最近一次 WiFi 实测速率 kbps，-1 表示测不通 */
    @Volatile var lastWifiKbps: Long = -1

    /** 最近一次蜂窝实测速率 kbps */
    @Volatile var lastCellKbps: Long = -1

    private val wifiCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            Log.i(TAG, "wifi network available: $network")
            wifi = network
            onChanged?.invoke()
        }
        override fun onLost(network: Network) {
            Log.i(TAG, "wifi lost: $network")
            if (wifi == network) wifi = null
            onChanged?.invoke()
        }
    }

    private val cellCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            Log.i(TAG, "cellular network available: $network")
            cellular = network
            onChanged?.invoke()
        }
        override fun onLost(network: Network) {
            Log.i(TAG, "cellular lost: $network")
            if (cellular == network) cellular = null
            onChanged?.invoke()
        }
    }

    var onChanged: (() -> Unit)? = null

    fun start() {
        val wifiReq = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val cellReq = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        runCatching { cm.requestNetwork(wifiReq, wifiCb) }
            .onFailure { Log.e(TAG, "request wifi failed", it) }
        runCatching { cm.requestNetwork(cellReq, cellCb) }
            .onFailure { Log.e(TAG, "request cell failed", it) }
    }

    fun stop() {
        runCatching { cm.unregisterNetworkCallback(wifiCb) }
        runCatching { cm.unregisterNetworkCallback(cellCb) }
        wifi = null
        cellular = null
    }

    private val rr = AtomicInteger(0)

    /**
     * 按权重选出口。这是一切的核心：
     * 视频、网页、下载都是多条 TCP 连接，加权轮询天然把它们铺到两条链路上，
     * 总吞吐接近两条之和。单条连接本身不会被拆开（内核按五元组哈希，拆不开）。
     */
    fun pick(): Network? {
        val w = wifi
        val c = cellular
        if (w == null && c == null) return null
        if (w == null) return c
        if (c == null) return w
        val weight = wifiWeight.coerceIn(0, 100)
        if (weight <= 0) return c
        if (weight >= 100) return w
        val i = (rr.getAndIncrement() and 0x7fffffff) % 100
        return if (i < weight) w else c
    }

    inline fun withWifi(block: (Network) -> Unit) { wifi?.let(block) }
    inline fun withCell(block: (Network) -> Unit) { cellular?.let(block) }
}
