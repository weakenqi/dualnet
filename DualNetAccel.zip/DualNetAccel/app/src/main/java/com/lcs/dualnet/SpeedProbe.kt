package com.lcs.dualnet

import android.net.Network
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * 通过指定的 Network 实测下行速率，用来决定 WiFi 权重。
 *
 * 用 network.openConnection(URL)：请求被迫从指定链路发出，
 * 不会因为默认网络是 WiFi 而测到别的路径。
 */
object SpeedProbe {

    private const val TAG = "SpeedProbe"

    /** 探测目标。选一个稳定、体积够大、支持 Range 的地址 */
    const val DEFAULT_PROBE_URL = "https://speed.cloudflare.com/__down?bytes=3000000"

    /**
     * @return kbps，失败返回 -1
     */
    fun measure(network: Network, url: String, budgetMs: Int = 4000): Long {
        var conn: HttpURLConnection? = null
        return try {
            val t0 = System.nanoTime()
            conn = network.openConnection(URL(url)) as HttpURLConnection
            conn.connectTimeout = budgetMs
            conn.readTimeout = budgetMs
            conn.instanceFollowRedirects = true
            conn.requestMethod = "GET"
            conn.connect()

            val code = conn.responseCode
            if (code !in 200..299) {
                Log.w(TAG, "probe http $code")
                return -1
            }

            val buf = ByteArray(16 * 1024)
            var total = 0L
            val deadline = t0 + budgetMs * 1_000_000L
            conn.inputStream.use { ins ->
                while (true) {
                    val n = ins.read(buf)
                    if (n <= 0) break
                    total += n
                    if (System.nanoTime() > deadline) break
                }
            }
            val sec = (System.nanoTime() - t0) / 1_000_000_000.0
            if (sec < 0.15 || total < 8192) return -1
            val kbps = ((total * 8) / sec / 1000).toLong()
            Log.i(TAG, "probe ${network} -> ${total}B in ${"%.2f".format(sec)}s = ${kbps}kbps")
            kbps
        } catch (e: Exception) {
            Log.w(TAG, "probe failed: ${e.message}")
            -1
        } finally {
            runCatching { conn?.disconnect() }
        }
    }
}

/**
 * 周期性测速，把结果换算成 WiFi 权重。
 *
 * 规则（可在 UI 里调）：
 *  - WiFi 实测 >= goodMbps          -> 权重 100（全部走 WiFi）
 *  - WiFi 实测在 lowMbps..goodMbps  -> 线性插值，WiFi 占一部分，流量补剩下的
 *  - WiFi 实测 <  lowMbps 或 测不通 -> 权重 0（全部走流量）
 *
 * 效果就是你要的：WiFi 够快就全用它；WiFi 掉下去，流量按比例补上来；
 * WiFi 完全不能用时，流量全接管；WiFi 恢复后自动退回去。
 */
class WeightController(
    private val registry: NetworkRegistry,
    private val probeUrl: String = SpeedProbe.DEFAULT_PROBE_URL,
) {
    var lowKbps: Long = 2_000       // 低于 2Mbps 认为很差
    var goodKbps: Long = 15_000     // 高于 15Mbps 认为够用
    var probeIntervalSec: Int = 10
    var probeBudgetMs: Int = 4000

    /**
     * WiFi 保底权重。即使 WiFi 慢到阈值下限以下，也保留这么多比例的连接走 WiFi，
     * 保证两条链路在任何时候都在同时承载，而不是退化成"只用流量"。
     * 设 0 = 允许完全退到只用流量。
     */
    var minWifiWeight: Int = 15

    private var exec: ScheduledExecutorService? = null

    fun start() {
        if (exec != null) return
        exec = Executors.newSingleThreadScheduledExecutor { r ->
            Thread(r, "weight-probe").apply { isDaemon = true }
        }.also {
            it.scheduleWithFixedDelay(::tick, 1, probeIntervalSec.toLong(), TimeUnit.SECONDS)
        }
    }

    fun stop() {
        exec?.shutdownNow()
        exec = null
        registry.wifiWeight = 100
    }

    private fun tick() {
        try {
            val wifi = registry.wifi
            if (wifi == null) {
                registry.lastWifiKbps = -1
                registry.wifiWeight = 0
                Stats.wifiKbps = -1
                Stats.weight = 0
                return
            }
            val kbps = SpeedProbe.measure(wifi, probeUrl, probeBudgetMs)
            registry.lastWifiKbps = kbps
            registry.wifiWeight = computeWeight(kbps)
            Stats.wifiKbps = kbps
            Stats.weight = registry.wifiWeight
        } catch (t: Throwable) {
            Log.w("WeightController", "tick error", t)
        }
    }

    /**
     * 权重映射：
     *  - 完全测不通（带宽为 0）        -> 0    分过去只会超时，没意义
     *  - 低于下限（还能通，就是慢）    -> minWifiWeight  保底并存
     *  - 下限~上限之间                -> 从 minWifiWeight 线性升到 100
     *  - 高于上限                     -> 100
     */
    fun computeWeight(kbps: Long): Int {
        if (kbps < 0) return 0
        val floor = minWifiWeight.coerceIn(0, 99)
        if (kbps <= lowKbps) return floor
        if (kbps >= goodKbps) return 100
        val span = (goodKbps - lowKbps).toDouble()
        val pos = (kbps - lowKbps).toDouble()
        val w = floor + (pos / span) * (100 - floor)
        return w.toInt().coerceIn(0, 100)
    }
}
